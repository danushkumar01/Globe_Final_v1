import React from 'react';
import Globe from './Globe.jsx';
import './App.css';

function App() {
  return (
    <div className="App">
      <Globe />
    </div>
  );
}

export default App;
